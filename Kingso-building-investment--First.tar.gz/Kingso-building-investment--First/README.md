# Kingso-building-investment-
Dealers in all kinds of quality building materials such as water heater, fittings, Doors, Geepee tanks, borehole materials, more 
